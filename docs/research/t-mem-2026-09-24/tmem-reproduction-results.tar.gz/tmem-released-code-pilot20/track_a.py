"""Released-code LoCoMo-Plus scene-only diagnostic, not a Table 4 cascade."""
import argparse
import asyncio
from collections import Counter
import hashlib
import ipaddress
import json
import os
import random
import sys
from pathlib import Path
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
UPSTREAM = ROOT / "upstream"
sys.path.insert(0, str(UPSTREAM))

from T_mem.config import ExperimentConfig, MODELS
from T_mem.llm.llm_provider import LLMProvider
from T_mem.main.stage0_locomo_plus_stitch import _stitch_one, stitch_locomo_plus
from T_mem.main.stage1_memory_extraction import load_locomo_raw_data, process_single_conversation
from T_mem.main.stage4_associative_extract import process_conv
from T_mem.main.stage5_retrieval_locomo import N_TURNS_SKIP, _embed_batch, prepare_conv, rrf_fuse_topk, score_one_query
from T_mem.main.stage5_retrieval_locomo_plus import _load_scenes_full
from T_mem.main.stage8_qa_locomo_plus import QA_COGNITIVE_WITH_CUE_PROMPT, _answer_record, _build_memory_context, _strip_ab_prefix
from T_mem.llm.embedding_provider import EmbeddingProvider
from benchmark_eval.locomo_plus.judge.evidence_loader import build_evidence_and_reltype_maps
from benchmark_eval.locomo_plus.judge.judge_prompts import get_prompt
from benchmark_eval.locomo_plus.judge.run_judge import run_one

PILOT = (9, 27, 47, 54, 58, 116, 128, 148, 160, 166, 214, 215, 244, 265, 294, 301, 302, 349, 367, 398)
DATA_HASHES = {"locomo10.json": "79fa87e90f04081343b8c8debecb80a9a6842b76a7aa537dc9fdf651ea698ff4", "locomo_plus.json": "af2fc6e5e0e88735e28d8dd1ef474b718861a73beb21779809e3b9e1a4fe3d23"}
ARMS = {"arm_0": ("b", "scene", "horizon"), "arm_1": ("b", "scene"), "arm_2": ("b",)}
RRF_K = 30
TOPK = 10


def digest(data):
    if isinstance(data, Path):
        h = hashlib.sha256()
        with data.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                h.update(chunk)
        return h.hexdigest()
    return hashlib.sha256(json.dumps(data, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")
    temp.replace(path)


def locked_json(path, expected):
    if path.exists():
        if json.loads(path.read_text(encoding="utf-8")) != expected:
            raise RuntimeError(f"manifest mismatch, refusing stale artifact: {path}")
    else:
        write_json(path, expected)


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def loopback_env(name):
    raw = os.environ.get(name, "")
    url = urlparse(raw)
    try:
        valid = url.scheme == "http" and ipaddress.ip_address(url.hostname or "").is_loopback
    except ValueError:
        valid = False
    if not valid:
        raise RuntimeError(f"{name} must be explicitly set to an http://127.0.0.1 loopback proxy")
    return raw.rstrip("/")


def source_inputs():
    for filename, expected in DATA_HASHES.items():
        if digest(ROOT / "data" / filename) != expected:
            raise RuntimeError(f"pinned input hash mismatch: {filename}")
    base = read_json(ROOT / "data/locomo10.json")
    plus = read_json(ROOT / "data/locomo_plus.json")
    if len(base) != 10 or len(plus) != 401:
        raise RuntimeError("expected the full 10-base / 401-evidence datasets")
    return base, plus


def rank_fuse(scores, channels, topk=TOPK, k=RRF_K):
    sids = list(scores)
    ranks = {channel: {sid: rank for rank, sid in enumerate(sorted(sids, key=lambda sid: (-scores[sid][channel], sid)), 1)} for channel in channels}
    fused = []
    for sid in sids:
        score = 1.0 / (k + ranks[channels[0]][sid])
        for channel in channels[1:]:
            score += 1.0 / (k + ranks[channel][sid])
        fused.append((sid, score))
    return sorted(fused, key=lambda pair: (-pair[1], pair[0]))[:topk], ranks


def case_paths(idx):
    case = ROOT / "track-a" / "cases" / f"sample_{idx:03d}"
    return case, case / "scenes" / f"scene_list_conv_{idx}.json", case / "triggers" / f"triggers_conv_{idx}.json"


def identity(idx, base, plus, llm_url):
    return {"track": "A-released-scene-only-v1", "upstream_commit": "dd9e1527bc75908485809580c9520af5a9a42879", "runner_sha": digest(Path(__file__)), "data_sha256": DATA_HASHES, "sample_id": f"sample_{idx:03d}", "original_index": idx, "base_conv_idx": idx % len(base), "base_record_sha": digest(base[idx % len(base)]), "plus_record_sha": digest(plus[idx]), "construction_model": MODELS["memory_build"], "llm_base_url": llm_url}


def verify_build(case, scene, trigger, ident):
    if read_json(case / "identity.json") != ident:
        raise RuntimeError(f"case identity changed: {case}")
    scenes, triggers = read_json(scene), read_json(trigger)
    ids = [s["scene_id"] for s in scenes]
    if not ids or len(ids) != len(set(ids)) or set(ids) != set(triggers.get("scenes", {})):
        raise RuntimeError(f"scene/trigger coverage mismatch: {case}")
    if any(triggers["scenes"][sid]["status"] not in ("ok", "skipped_by_n_turns", "skipped_empty", "parse_failed") for sid in ids):
        raise RuntimeError(f"incomplete trigger extraction: {case}")
    manifest = read_json(case / "build.json")
    expected = {"identity_sha": digest(ident), "scene_sha": digest(scene), "trigger_sha": digest(trigger), "coverage": build_coverage(scenes, triggers)}
    if manifest != expected:
        raise RuntimeError(f"incomplete or changed construction: {case}")
    return manifest


def build_coverage(scenes, triggers):
    statuses = Counter(triggers["scenes"][scene["scene_id"]]["status"] for scene in scenes)
    return {"scene_count": len(scenes), "trigger_statuses": dict(sorted(statuses.items())), "pending_summary_count": sum(scene.get("summary") == "(pending)" for scene in scenes)}


async def build(ids, base, plus, llm_url):
    stitched = ROOT / "track-a" / "stitched-full.json"
    if not stitched.exists():
        stitch_locomo_plus(ROOT / "data/locomo10.json", ROOT / "data/locomo_plus.json", stitched)
    stitched_rows = read_json(stitched)
    if len(stitched_rows) != 401:
        raise RuntimeError("stitched input must contain all original indices")
    for idx in ids:
        if stitched_rows[idx] != _stitch_one(idx, idx % len(base), plus[idx], base[idx % len(base)]):
            raise RuntimeError(f"stitched sample does not match pinned original ID: {idx}")
    del stitched_rows
    needs = []
    for idx in ids:
        case, scene, trigger = case_paths(idx)
        ident = identity(idx, base, plus, llm_url)
        locked_json(case / "identity.json", ident)
        if (case / "build.json").exists():
            existing = verify_build(case, scene, trigger, ident)
            print(f"resumed sample_{idx:03d}: {existing['coverage']}")
        else:
            needs.append(idx)
    if not needs:
        return
    raw = load_locomo_raw_data(str(stitched))
    first = LLMProvider(model=MODELS["memory_build"], temperature=0.0, max_tokens=ExperimentConfig.llm_config["openai"]["max_tokens"])
    fourth = LLMProvider(model=MODELS["memory_build"], timeout=240, retries=3, json_max_retries=3)
    cap = max(1, int(os.environ.get("T_MEM_MAX_CONCURRENCY") or "14"))
    semaphore = asyncio.Semaphore(cap)

    async def one_case(idx):
        async with semaphore:
            case, scene, trigger = case_paths(idx)
            scene.parent.mkdir(parents=True, exist_ok=True)
            if not scene.exists():
                await process_single_conversation(str(idx), raw[str(idx)], scene.parent, llm_provider=first)
            if not scene.exists() or not read_json(scene):
                raise RuntimeError(f"Stage 1 did not finish sample_{idx:03d}")
            await process_conv(fourth, idx, scene, trigger, concurrency=1, resume=True)
            scenes, payload = read_json(scene), read_json(trigger)
            ids_in_scene = [s["scene_id"] for s in scenes]
            if len(ids_in_scene) != len(set(ids_in_scene)) or set(ids_in_scene) != set(payload.get("scenes", {})):
                raise RuntimeError(f"Stage 4 coverage incomplete: {idx}")
            if any(payload["scenes"][sid]["status"] not in ("ok", "skipped_by_n_turns", "skipped_empty", "parse_failed") for sid in ids_in_scene):
                raise RuntimeError(f"Stage 4 not terminal: {idx}")
            ident = identity(idx, base, plus, llm_url)
            coverage = build_coverage(scenes, payload)
            write_json(case / "build.json", {"identity_sha": digest(ident), "scene_sha": digest(scene), "trigger_sha": digest(trigger), "coverage": coverage})
            verify_build(case, scene, trigger, ident)
            print(f"built sample_{idx:03d}: {coverage}")

    async with asyncio.TaskGroup() as tasks:
        for idx in needs:
            tasks.create_task(one_case(idx))


def retrieve(ids, base, plus, llm_url, embedding_url):
    model = os.environ.get("T_MEM_EMBEDDING_MODEL", "bge-m3")
    if model not in ("bge-m3", "baai/bge-m3"):
        raise RuntimeError("Track A requires BGE-M3, not a substituted embedding")
    emb = EmbeddingProvider(timeout=60, max_retries=5)
    for idx in ids:
        case, scene, trigger = case_paths(idx)
        construction = verify_build(case, scene, trigger, identity(idx, base, plus, llm_url))
        expected = {"build_sha": digest(construction), "embedding_url": embedding_url, "embedding_model": model, "query_sha": digest((plus[idx].get("trigger_query") or "").strip()), "rrf_k": RRF_K, "topk": TOPK}
        target = case / "retrieval.json"
        if target.exists():
            if read_json(target)["input"] != expected or read_json(case / "retrieval-manifest.json") != {"retrieval_sha": digest(target), "input_sha": digest(expected)}:
                raise RuntimeError(f"retrieval input changed: {target}")
            continue
        prep = prepare_conv(idx, scene, trigger, emb)
        query = (plus[idx].get("trigger_query") or "").strip()
        if not query or not prep["scenes_order"]:
            raise RuntimeError(f"empty query or scene library: {idx}")
        per_scene = score_one_query(_embed_batch(emb, [query])[0], prep)
        full, ranks = rank_fuse(per_scene, ARMS["arm_0"])
        if full != rrf_fuse_topk(per_scene, topk=TOPK, k=RRF_K):
            raise RuntimeError("full arm differs from released RRF")
        content = _load_scenes_full(scene)
        result = {"input": expected, "sample_id": f"sample_{idx:03d}", "scores": per_scene, "channel_ranks": ranks, "arms": {}}
        for arm, channels in ARMS.items():
            fused, _ = rank_fuse(per_scene, channels)
            rows = []
            for position, (sid, score) in enumerate(fused, 1):
                stats = prep["scenes"][sid]
                rows.append({"rank": position, "scene_id": sid, "score": round(float(score), 6), "n_turns": stats["n_turns"], "skipped": stats["n_turns"] > N_TURNS_SKIP, **content[sid]})
            result["arms"][arm] = rows
        if [r["scene_id"] for r in result["arms"]["arm_2"]] != sorted(per_scene, key=lambda sid: (-per_scene[sid]["b"], sid))[:TOPK]:
            raise RuntimeError("b-only ordering differs from raw-dialogue cosine")
        write_json(target, result)
        write_json(case / "retrieval-manifest.json", {"retrieval_sha": digest(target), "input_sha": digest(expected)})
        print(f"retrieved sample_{idx:03d}: {len(per_scene)} scenes / 3 arms")


async def score(ids, base, plus, llm_url, embedding_url):
    model = os.environ.get("T_MEM_EMBEDDING_MODEL", "bge-m3")
    retrievals = {}
    for idx in ids:
        case, scene, trigger = case_paths(idx)
        manifest = verify_build(case, scene, trigger, identity(idx, base, plus, llm_url))
        path = case / "retrieval.json"
        result = read_json(path)
        expected = {"build_sha": digest(manifest), "embedding_url": embedding_url, "embedding_model": model, "query_sha": digest((plus[idx].get("trigger_query") or "").strip()), "rrf_k": RRF_K, "topk": TOPK}
        if result["input"] != expected or read_json(case / "retrieval-manifest.json") != {"retrieval_sha": digest(path), "input_sha": digest(expected)} or set(result["arms"]) != set(ARMS) or any(not result["arms"][arm] for arm in ARMS):
            raise RuntimeError(f"incomplete or changed retrieval: {path}")
        retrievals[idx] = result
    scope = {"original_ids": ids, "retrieval_sha": {str(idx): digest(case_paths(idx)[0] / "retrieval.json") for idx in ids}, "llm_url": llm_url, "qa_model": MODELS["locomo_plus_qa"], "judge_model": MODELS["locomo_plus_judge"], "qa_prompt_sha": digest(QA_COGNITIVE_WITH_CUE_PROMPT), "judge_prompt_sha": digest(get_prompt("A_paper_original")), "full_evidence_sha": DATA_HASHES["locomo_plus.json"]}
    out = ROOT / "track-a" / "scopes" / digest(scope)[:24]
    locked_json(out / "scope.json", scope)
    provider = LLMProvider(model=MODELS["locomo_plus_qa"], temperature=0.0)
    jobs = [(idx, arm) for idx in ids for arm in ARMS]
    random.Random("track-a-v1:" + digest(scope)).shuffle(jobs)
    for idx, arm in jobs:
        sid = f"sample_{idx:03d}"
        rows = retrievals[idx]["arms"][arm]
        conv = base[idx % len(base)]["conversation"]
        sa, sb = conv["speaker_a"], conv["speaker_b"]
        question = _strip_ab_prefix((plus[idx].get("trigger_query") or "").strip())
        if not question:
            raise RuntimeError(f"empty reader input: {sid}")
        prompt = QA_COGNITIVE_WITH_CUE_PROMPT.format(speaker_a=sa, speaker_b=sb, memory_context=_build_memory_context(rows, "summary"), trigger=question)
        fingerprint = {"retrieval_sha": scope["retrieval_sha"][str(idx)], "arm": arm, "prompt_sha": digest(prompt), "model": provider.model}
        path = out / arm / "answers" / f"{sid}.json"
        if path.exists():
            if read_json(path)["input"] != fingerprint:
                raise RuntimeError(f"stale QA cache: {path}")
            continue
        answer = await _answer_record(provider, sample_id=sid, trigger=question, speaker_a=sa, speaker_b=sb, topk_rows=rows, content="summary", sem=asyncio.Semaphore(1))
        write_json(path, {"input": fingerprint, "record": answer})
        print(f"answered {sid} {arm}")
    judge_order = list(ARMS)
    random.Random("judge:" + digest(scope)).shuffle(judge_order)
    for arm in judge_order:
        arm_dir = out / arm
        predictions = [read_json(arm_dir / "answers" / f"sample_{idx:03d}.json")["record"] for idx in ids]
        pred_path = arm_dir / "predictions.json"
        locked_json(pred_path, predictions)
        evidence, types = build_evidence_and_reltype_maps(predictions, plus)
        if set(evidence) != {f"sample_{idx:03d}" for idx in ids} or any(not evidence[sid] for sid in evidence):
            raise RuntimeError("full original-ID evidence missing")
        judge_key = digest({"prediction_sha": digest(pred_path), "evidence": evidence, "types": types, "model": MODELS["locomo_plus_judge"], "prompt": get_prompt("A_paper_original"), "upstream": scope})[:24]
        judged_dir = arm_dir / "judgments" / judge_key
        run_one(predictions_file=pred_path, evidence_map=evidence, rt_map=types, method=arm, prompt_key="A_paper_original", prompt_template=get_prompt("A_paper_original"), judge_model=MODELS["locomo_plus_judge"], num_runs=1, concurrency=1, timeout=120, max_retries=4, out_dir=judged_dir)
        judged = read_json(judged_dir / "judge.json")
        if [r["sample_id"] for r in judged["details"]] != [f"sample_{idx:03d}" for idx in ids] or any(r["evidence"] != evidence[r["sample_id"]] for r in judged["details"]):
            raise RuntimeError(f"judge evidence or original IDs mismatch: {judged_dir}")
        print(f"judged {arm}: {judged_dir}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("validate", "build", "retrieve", "score"))
    parser.add_argument("--ids", default="pilot", help="pilot or one original index from the frozen pilot")
    parser.add_argument("--admitted-by-root", action="store_true", help="explicitly permits paid phase execution through a root-controlled loopback proxy")
    args = parser.parse_args()
    ids = list(PILOT) if args.ids == "pilot" else [int(args.ids)]
    if not ids or any(i not in PILOT for i in ids):
        parser.error("IDs must be the frozen pilot or one of its original IDs")
    base, plus = source_inputs()
    if args.phase == "validate":
        for idx in ids:
            rec = _stitch_one(idx, idx % len(base), plus[idx], base[idx % len(base)])
            assert rec["sample_idx"] == idx and rec["base_conv_idx"] == idx % 10
            assert rec["sample_id"] == f"sample_{idx:03d}" and rec["conversation"]["speaker_a"] == base[idx % 10]["conversation"]["speaker_a"]
        print(f"Track A pinned inputs and original IDs validated: {len(ids)}")
        return
    if not args.admitted_by_root:
        parser.error("paid phases require --admitted-by-root after root approval")
    if [MODELS[k] for k in ("memory_build", "locomo_plus_qa", "locomo_plus_judge")] != ["gpt-4.1-mini", "gpt-4o", "gemini-2.5-flash"]:
        parser.error("Track A model alias changed from released original")
    llm_url = loopback_env("T_MEM_LLM_BASE_URL")
    if args.phase == "build":
        asyncio.run(build(ids, base, plus, llm_url))
    else:
        embedding_url = loopback_env("T_MEM_EMBEDDING_BASE_URL")
        if args.phase == "retrieve":
            retrieve(ids, base, plus, llm_url, embedding_url)
        else:
            asyncio.run(score(ids, base, plus, llm_url, embedding_url))


if __name__ == "__main__":
    main()
