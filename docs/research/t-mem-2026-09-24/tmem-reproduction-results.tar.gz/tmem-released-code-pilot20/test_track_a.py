import asyncio
import os
import random
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import track_a as t
from T_mem.main.stage5_retrieval_locomo import rrf_fuse_topk
from T_mem.main.stage8_qa_locomo_plus import _build_memory_context
from benchmark_eval.locomo_plus.judge.evidence_loader import build_evidence_and_reltype_maps


class TrackATests(unittest.TestCase):
    def test_full_rrf_exactly_matches_release_including_ties(self):
        rng = random.Random(143)
        for count in (1, 3, 20):
            for _ in range(20):
                scores = {f"scene_{i:03d}": {c: rng.choice([0.0, 0.0, rng.random()]) for c in ("b", "scene", "horizon")} for i in range(count)}
                self.assertEqual(t.rank_fuse(scores, t.ARMS["arm_0"])[0], rrf_fuse_topk(scores, 10, 30))

    def test_b_only_and_disabled_horizon_no_votes(self):
        scores = {
            "a": {"b": 0.9, "scene": 0.0, "horizon": -1.0},
            "b": {"b": 0.8, "scene": 0.0, "horizon": 0.2},
            "c": {"b": 0.7, "scene": 0.0, "horizon": 2.0},
        }
        self.assertEqual([sid for sid, _ in t.rank_fuse(scores, t.ARMS["arm_2"])[0]], ["a", "b", "c"])
        no_horizon = t.rank_fuse(scores, t.ARMS["arm_1"])[0]
        scores["a"]["horizon"] = 1000.0
        scores["b"]["horizon"] = -1000.0
        self.assertEqual(t.rank_fuse(scores, t.ARMS["arm_1"])[0], no_horizon)
        self.assertEqual(len(t.rank_fuse(scores, t.ARMS["arm_1"])[1]), 2)

    def test_pinned_full_evidence_original_ids_and_base(self):
        base, plus = t.source_inputs()
        self.assertEqual(len(plus), 401)
        for idx in t.PILOT:
            rec = t._stitch_one(idx, idx % 10, plus[idx], base[idx % 10])
            sid = f"sample_{idx:03d}"
            self.assertEqual((rec["sample_id"], rec["sample_idx"], rec["base_conv_idx"]), (sid, idx, idx % 10))
            self.assertEqual(rec["conversation"]["speaker_a"], base[idx % 10]["conversation"]["speaker_a"])
            prediction = [{"sample_id": sid, "speaker_a": rec["conversation"]["speaker_a"], "speaker_b": rec["conversation"]["speaker_b"]}]
            evidence, relations = build_evidence_and_reltype_maps(prediction, plus)
            self.assertTrue(evidence[sid])
            self.assertEqual(relations[sid], plus[idx]["relation_type"])

    def test_incomplete_build_and_mutated_cache_fail_closed(self):
        with tempfile.TemporaryDirectory() as temp:
            case = Path(temp)
            scene = case / "scenes.json"
            trigger = case / "triggers.json"
            identity = {"index": 9}
            t.write_json(case / "identity.json", identity)
            t.write_json(scene, [{"scene_id": "x"}])
            t.write_json(trigger, {"scenes": {"x": {"status": "llm_failed"}}})
            t.write_json(case / "build.json", {"identity_sha": t.digest(identity), "scene_sha": t.digest(scene), "trigger_sha": t.digest(trigger), "coverage": t.build_coverage(t.read_json(scene), t.read_json(trigger))})
            with self.assertRaises(RuntimeError):
                t.verify_build(case, scene, trigger, identity)
            t.write_json(trigger, {"scenes": {"x": {"status": "ok"}}})
            with self.assertRaises(RuntimeError):
                t.verify_build(case, scene, trigger, identity)
            t.write_json(case / "build.json", {"identity_sha": t.digest(identity), "scene_sha": t.digest(scene), "trigger_sha": t.digest(trigger), "coverage": t.build_coverage(t.read_json(scene), t.read_json(trigger))})
            t.verify_build(case, scene, trigger, identity)
            with self.assertRaises(RuntimeError):
                t.locked_json(case / "identity.json", {"index": 27})
            with patch.object(t, "case_paths", return_value=(case / "missing", scene, trigger)):
                base, plus = t.source_inputs()
                with self.assertRaises(FileNotFoundError):
                    asyncio.run(t.score([9], base, plus, "http://127.0.0.1:9000/v1", "http://127.0.0.1:9000/v1"))

    def test_bounded_build_preserves_each_history_order_and_reports_statuses(self):
        base, plus = t.source_inputs()
        for cap in (1, 2):
            with tempfile.TemporaryDirectory() as temp:
                root = Path(temp)
                (root / "track-a").mkdir()
                stitched = root / "track-a/stitched-full.json"
                stitched.touch()
                rows = [None] * 401
                for idx in (9, 27):
                    rows[idx] = t._stitch_one(idx, idx % 10, plus[idx], base[idx % 10])
                real_read = t.read_json

                def read(path):
                    return rows if path == stitched else real_read(path)

                active = 0
                peak = 0
                stages = {9: [], 27: []}

                async def first(idx, _raw, output, llm_provider):
                    nonlocal active, peak
                    idx = int(idx)
                    active += 1
                    peak = max(peak, active)
                    stages[idx].append("stage1-start")
                    await asyncio.sleep(0.01)
                    t.write_json(output / f"scene_list_conv_{idx}.json", [{"scene_id": f"scene-{idx}", "summary": "(pending)" if idx == 9 else "ready"}])
                    stages[idx].append("stage1-end")
                    active -= 1

                async def fourth(_llm, idx, _scene, output, concurrency, resume):
                    stages[idx].append("stage4")
                    status = "parse_failed" if idx == 9 else "ok"
                    value = {"scenes": {f"scene-{idx}": {"status": status}}}
                    t.write_json(output, value)
                    return value

                with patch.object(t, "ROOT", root), patch.object(t, "read_json", side_effect=read), patch.object(t, "load_locomo_raw_data", return_value={"9": [], "27": []}), patch.object(t, "LLMProvider", return_value=object()), patch.object(t, "process_single_conversation", side_effect=first), patch.object(t, "process_conv", side_effect=fourth), patch.dict(os.environ, {"T_MEM_MAX_CONCURRENCY": str(cap)}):
                    asyncio.run(t.build([9, 27], base, plus, "http://127.0.0.1:9000/v1"))
                self.assertEqual(peak, cap)
                self.assertEqual(stages[9], ["stage1-start", "stage1-end", "stage4"])
                self.assertEqual(stages[27], ["stage1-start", "stage1-end", "stage4"])
                self.assertEqual(real_read(root / "track-a/cases/sample_009/build.json")["coverage"], {"scene_count": 1, "trigger_statuses": {"parse_failed": 1}, "pending_summary_count": 1})

    def test_reader_context_and_arm_cache_boundaries(self):
        rows = [{"rank": 1, "summary": "cue", "scene_id": "x"}]
        self.assertEqual(_build_memory_context(rows, "summary"), "## Recalled Experience\n\n[Memory 1]\ncue")
        self.assertEqual(len(t.ARMS), 3)
        self.assertEqual(len(set(t.ARMS)), 3)
        self.assertNotEqual(t.digest({"arm": "arm_0", "prompt": "same"}), t.digest({"arm": "arm_1", "prompt": "same"}))
        self.assertNotEqual(t.digest({"prediction_sha": "one"}), t.digest({"prediction_sha": "two"}))


if __name__ == "__main__":
    unittest.main()
