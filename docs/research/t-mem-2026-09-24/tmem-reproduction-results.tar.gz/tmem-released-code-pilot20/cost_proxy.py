import argparse
import decimal
import gzip
import fcntl
import hashlib
import json
import math
import os
import pathlib
import threading
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

D = decimal.Decimal
ROUTES = {
    'gpt-4.1-mini': ('openai/gpt-4.1-mini', 'openai', '0.0000004', '0.0000016', 32768),
    'gpt-4o': ('openai/gpt-4o', 'openai', '0.0000025', '0.00001', 16384),
    'gemini-2.5-flash': ('google/gemini-2.5-flash', 'google-ai-studio', '0.0000003', '0.0000025', 65535),
    'bge-m3': ('baai/bge-m3', 'deepinfra/fp32', '0.00000001', '0', 0),
}
for _route in list(ROUTES.values()):
    ROUTES[_route[0]] = _route


def prepare(path, body):
    route = ROUTES.get(body.get('model'))
    if route is None:
        raise ValueError('unapproved model')
    model, provider, input_price, output_price, native_max = route
    if path == '/v1/chat/completions' and native_max:
        if set(body) - {'model', 'messages', 'temperature'}:
            raise ValueError('unexpected chat parameters')
        messages = body.get('messages')
        if not isinstance(messages, list) or not messages:
            raise ValueError('missing messages')
        if any(not isinstance(m, dict) or set(m) != {'role', 'content'} or m['role'] not in {'user', 'system', 'assistant'} or not isinstance(m['content'], str) for m in messages):
            raise ValueError('non-text request')
        wire = dict(body, model=model, max_tokens=native_max)
        token_bound = len(json.dumps(messages, ensure_ascii=False).encode()) + 1024 * len(messages)
    elif path == '/v1/embeddings' and not native_max:
        if set(body) != {'model', 'input'} or not isinstance(body['input'], list) or not body['input'] or any(not isinstance(s, str) for s in body['input']):
            raise ValueError('unexpected embedding parameters')
        wire = dict(body, model=model)
        token_bound = sum(len(s.encode()) + 64 for s in body['input'])
    else:
        raise ValueError('unapproved endpoint/model combination')
    wire['provider'] = {'only': [provider], 'allow_fallbacks': False}
    reserve = D(token_bound) * D(input_price) + D(native_max) * D(output_price)
    return wire, reserve


class Gate:
    def __init__(self, root, budget, max_requests, deadline):
        self.root = pathlib.Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.owner = (self.root / '.owner.lock').open('a')
        fcntl.flock(self.owner, fcntl.LOCK_EX | fcntl.LOCK_NB)
        self.ledger = self.root / 'ledger.ndjson'
        self.budget = D(str(budget))
        self.max_requests = max_requests
        self.deadline = deadline
        self.lock = threading.Lock()
        self.pending = {}
        self.spent = D(0)
        self.count = 0
        self.halted = False
        if self.ledger.exists():
            for line in self.ledger.read_text().splitlines():
                row = json.loads(line)
                if row['event'] == 'reserved':
                    self.pending[row['id']] = D(row['reserved_usd'])
                    self.count = max(self.count, row['id'])
                elif row['event'] == 'settled':
                    self.pending.pop(row['id'], None)
                    self.spent += D(row['cost_usd'])
                    self.halted = self.halted or row['over_reservation']
        if self.budget <= 0 or not self.budget.is_finite():
            raise ValueError('invalid budget')

    def append(self, row):
        with self.ledger.open('a') as f:
            f.write(json.dumps(dict(row, at_epoch=time.time()), allow_nan=False) + '\n')
            f.flush()
            os.fsync(f.fileno())

    def reserve(self, wire, amount):
        with self.lock:
            if self.halted or time.time() >= self.deadline or self.count >= self.max_requests or self.spent + sum(self.pending.values()) + amount > self.budget:
                raise ValueError('admission budget/deadline/request limit reached')
            self.count += 1
            rid = self.count
            target = self.root / f'request-{rid:06d}'
            target.mkdir(exist_ok=False)
            raw = json.dumps(wire, ensure_ascii=False).encode()
            (target / 'request.json').write_bytes(raw)
            self.append({'event': 'reserved', 'id': rid, 'reserved_usd': str(amount), 'model': wire['model'], 'request_sha256': hashlib.sha256(raw).hexdigest()})
            self.pending[rid] = amount
            return rid, target

    def settle(self, rid, result, status):
        usage = result.get('usage', {}) if isinstance(result, dict) else {}
        usage = usage if isinstance(usage, dict) else {}
        cost = usage.get('cost')
        external = usage.get('cost_details', {}).get('upstream_inference_cost') if isinstance(usage.get('cost_details'), dict) else None
        valid = lambda x: isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) and x >= 0
        if usage.get('is_byok') is True:
            cost = D(str(cost)) + D(str(external)) if valid(cost) and valid(external) else None
        with self.lock:
            if (isinstance(cost, D) and cost.is_finite() and cost >= 0) or valid(cost):
                charge = D(str(cost))
                over = charge > self.pending[rid]
                self.append({'event': 'settled', 'id': rid, 'cost_usd': str(charge), 'status': status, 'response_model': result.get('model'), 'provider': result.get('provider'), 'over_reservation': over, 'openrouter_cost_usd': usage.get('cost'), 'is_byok': usage.get('is_byok'), 'upstream_inference_cost_usd': external})
                self.pending.pop(rid)
                self.spent += charge
                self.halted = self.halted or over
            else:
                self.append({'event': 'unknown', 'id': rid, 'status': status, 'reserved_usd': str(self.pending[rid])})

    def status(self):
        with self.lock:
            return {'requests': self.count, 'reported_usd': str(self.spent), 'reserved_usd': str(sum(self.pending.values())), 'unsettled_requests': len(self.pending), 'budget_usd': str(self.budget), 'halted': self.halted, 'deadline_epoch': self.deadline}


def validate_embedding(result, count):
    rows = result.get('data', [])
    if len(rows) != count or sorted(r.get('index') for r in rows) != list(range(count)):
        raise ValueError('embedding count/index mismatch')
    if any(len(r.get('embedding', [])) != 1024 or any(not isinstance(v, (float, int)) or not math.isfinite(v) for v in r['embedding']) for r in rows):
        raise ValueError('embedding dimension/value mismatch')


def serve(gate, port):
    key = os.environ['OPENROUTER_API_KEY']

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *args):
            pass

        def respond(self, code, raw):
            self.send_response(code)
            self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(raw)))
            self.end_headers()
            try:
                self.wfile.write(raw)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def do_GET(self):
            self.respond(200 if self.path == '/health' else 404, json.dumps(gate.status() if self.path == '/health' else {'error': 'not found'}).encode())

        def do_POST(self):
            rid = None
            try:
                size = int(self.headers.get('Content-Length', '0'))
                if size <= 0 or size > 8 * 1024 * 1024:
                    raise ValueError('invalid body size')
                body = json.loads(self.rfile.read(size))
                wire, amount = prepare(self.path, body)
                rid, target = gate.reserve(wire, amount)
            except Exception as e:
                self.respond(403, json.dumps({'error': type(e).__name__ + ': ' + str(e)}).encode())
                return
            try:
                req = urllib.request.Request('https://openrouter.ai/api' + self.path, data=json.dumps(wire).encode(), headers={'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
                try:
                    with urllib.request.urlopen(req, timeout=390) as response:
                        status, raw = response.status, response.read()
                except urllib.error.HTTPError as e:
                    status, raw = e.code, e.read()
                with gzip.open(target / 'response.json.gz', 'wb') as f:
                    f.write(raw)
                result = json.loads(raw)
                gate.settle(rid, result, status)
                if status == 200 and self.path == '/v1/embeddings':
                    validate_embedding(result, len(wire['input']))
                self.respond(status, raw)
            except Exception as e:
                with gate.lock:
                    gate.append({'event': 'transport_or_validation_error', 'id': rid, 'type': type(e).__name__})
                self.respond(502, json.dumps({'error': type(e).__name__, 'request_id': rid, 'unknown_charge_retained': rid in gate.pending}).encode())

    print(json.dumps({'listening': f'127.0.0.1:{port}', **gate.status()}), flush=True)
    ThreadingHTTPServer(('127.0.0.1', port), Handler).serve_forever()


if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--budget', type=float, required=True)
    p.add_argument('--max-requests', type=int, required=True)
    p.add_argument('--deadline', type=float, required=True)
    p.add_argument('--port', type=int, default=8766)
    a = p.parse_args()
    serve(Gate(a.root, a.budget, a.max_requests, a.deadline), a.port)
