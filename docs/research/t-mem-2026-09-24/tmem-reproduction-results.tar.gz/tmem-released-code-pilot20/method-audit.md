# T-Mem Table 4 methods audit

**Verdict:** the released code supports a matched Scene/Horizon *scene-only* ablation, but its documented LoCoMo-Plus command does **not** implement the paper's claimed shared hierarchical cascade. Running that command, even after changing RRF to 60, is a released-code reproduction, not a faithful Table 4 replication. No scored comparison or provider call was made in this audit.

Audit date: 2026-09-24. Sources: `/home/user/.capy/work/t-mem-research/T-Mem` at `dd9e1527bc75908485809580c9520af5a9a42879`; sibling `paper.html` identifies arXiv `2606.15405v2`, 08 Sep 2026 (HTML line 251). Code references below are relative to that checkout; `paper.txt` references are to its sibling. Source checkout was read-only. Gstack installation/browser check passed. No private LongMemEval input or user data was read.

## 1. Target and denominator

- Table 4 reports Cognitive memory-awareness accuracy: full **74.81%**, no Horizon **62.34%**, no Scene + Horizon **52.62%** (`paper.txt:1396–1484`). The intended comparisons are +12.47 and +22.19 percentage points. These numbers are *author reports*, not our measurements. They are arithmetically consistent with 300, 250, and 211 correct out of 401, respectively; without original predictions this does not establish the actual counts.
- The paper explicitly reports only the new Cognitive subset as its LoCoMo-Plus score (`paper.txt:1245–1263`). Do not pool original LoCoMo questions, use ten base conversations as the accuracy denominator, or interpret this as ordinary exact-answer accuracy.
- One unit is a **cue/trigger-query sample paired with a base conversation**, not a scene or an independent person. Released stage 0 creates a separate memory library for every sample: `sample_i` uses base LoCoMo conversation `i % 10`, inserts cue at `last_session + 7 days - parsed_gap`, and query at `last_session + 7 days` (`stage0_locomo_plus_stitch.py:97–125,159–203`). Stage 5 retrieves only from library `i` (`stage5_retrieval_locomo_plus.py:88–94,139–151`). This means 401 isolated sample-specific builds, **not ten shared libraries containing all 401 cues**.
- Public benchmark revision freshly checked: `xjtuleeyf/Locomo-Plus` HEAD `059f4e3d38f7f1f96765e8e2cb7de3097551bffb`; `data/locomo_plus.json` last modified at `143cdeb649231612abc3304793bb36a122f94229` (2026-02-11). File SHA-256 `af2fc6e5e0e88735e28d8dd1ef474b718861a73beb21779809e3b9e1a4fe3d23`. **401 rows: causal 101, state 100, goal 100, value 100.** The original scores/ranks/model-name fields are generation metadata, not scoring targets or permissible selection criteria.
- Base data: `snap-research/LoCoMo` HEAD `3eb6f2c585f5e1699204e3c3bdf7adc5c28cb376`; `data/locomo10.json` last modified at `cbfbc1dba6bc53d00625212a0f22d55ffee7c1fc` (2024-08-10), ten conversations, SHA-256 `79fa87e90f04081343b8c8debecb80a9a6842b76a7aa537dc9fdf651ea698ff4`.
- These are current, pinned public files, not proof of the exact files used for Table 4. The released downloader tracks mutable `main` and silently keeps existing files (`scripts/download_data.sh:25–27,41–50`). Public file copies, source-history records, and manifests are saved in `audit-public/` beside this audit.

## 2. Paper settings versus executable route

| Setting | Paper v2 | Released implementation |
|---|---|---|
| Build / QA / judge | GPT-4.1-mini / GPT-4o / Gemini-2.5-Flash | Matching aliases in `T_mem/config.py:18–24`; actual endpoint/model revisions remain execution-time facts |
| Dense / reranker | BGE-M3 / BGE-reranker-v2-m3 | Configured at `config.py:69–73,104–112`; Plus route never calls the reranker |
| Final topic / scene / item budgets | 15 / 5 / 15 | Hierarchical config has 15 topics, wide 24 scenes/40 items, post-trim 5/15 (`config.py:79–102`); Plus reader instead defaults to **10 scene summaries** |
| Item-trigger union / hard cosine gate | 10 / 0.85 | Stage 6 implements these (`stage6_retrieval.py:38–75`), but Plus skips it |
| RRF smoothing | 60 throughout | Stage 6 uses 60 (`stage6_retrieval.py:34–35`); stage 5 uses **30**, imported by Plus (`stage5_retrieval_locomo.py:25–26`; Plus `:32–39`) |
| Retrieval cascade | Same on both benchmarks | `scripts/eval_locomo_plus.sh:152–182` runs stage 5 directly into stage 8, then judge at `:193–203` |

Paper references: construction/QA/judge `paper.txt:1354–1367`; same cascade and all hyperparameters `:4256–4307`. `paper.txt:1599–1606` explicitly says item components are retrieved and supplied to Plus QA, so omission is not merely an ambiguous diagram.

The released Plus reader consumes only `locomo_plus_topk_per_sample.json` scene fields (`stage8_qa_locomo_plus.py:65–80,203–208,345–346`). It has no item, persona, topic or reranker input. Building those artifacts does not make it consume them. Setting `--topk 5` only trims scenes; it does not supply 15 items or implement the topic filter.

Nor can one simply insert stage 6 into the shell script: stitched records have `qa: []` (`stage0...:171`), stage 6 iterates `conversation_data['qa']` (`stage6...:1162–1191`), and its association loader expects `per_qa[{conv_id,question,topk}]` (`:153–164`), whereas Plus stage 5 writes `samples{sample_id: rows}` (`stage5...plus:179–190`). A paper-settings attempt requires an explicit adapter and Plus context/reader integration, or an author-supplied runner. Neither is present as an executable released Table 4 route.

Changing `T_MEM_SCENE_HORIZON_RRF_K=60` does change stage-5 fusion (`stage5...plus:215–216`), but the output `method` string remains hard-coded `RRF_k30_3way` (`:180`); trust recorded arguments/numeric `rrf_k`, not that label.

## 3. Exact reader and judge

Released QA defaults to `gpt-4o` (`config.py:22`; `stage8...plus:60`). Temperature is 0 (`stage8...plus:143,303`). The prompt is the following literal template (`stage8...plus:35–43`):

```text
You are continuing a conversation between {speaker_a} and {speaker_b}.

{memory_context}

Latest message from {speaker_a}: {trigger}

You must respond as {speaker_b}, drawing on the recalled experience above. Do NOT ignore or contradict the recalled information. Weave it naturally into your response.

Respond as {speaker_b}:
```

`memory_context` is `## Recalled Experience`, then blank-line-separated `[Memory {rank}]\n{summary}` blocks by default; empty body becomes `(empty)` (`:65–80`). The query has one leading `A:`/`B:` stripped (`:47–53,124–132`), whereas stage-5 embedding uses the original stripped-whitespace `trigger_query` including its prefix (`stage5...plus:130–135`). Do not silently change those two query forms between arms. The QA prompt does not receive cue evidence directly; it receives whichever scene content retrieval returns.

Judge defaults: `gemini-2.5-flash`, one judgment per prediction (`run_judge.py:40–44`; shell `:34–35`). It calls the shared grader helper at temperature 0, prepending `You are an expert grader that determines if answers to questions match a gold standard answer.\n\n` (`benchmark_eval/locomo/runner/memos_judge.py:35–53`) to this template (`judge/judge_prompts.py:7–25`):

```text
You are a Memory Awareness Judge. Your task is to determine whether the model's response demonstrates recall of the memory cue described in the Evidence.

Question:
{question}

Memory/Evidence:
{evidence}

Model Prediction:
{pred}

Labels:
- "correct": explicitly acknowledges or adapts to the Memory/Cue (proves recall).
- "wrong": completely ignores the Evidence and gives a generic response.

Return your judgment strictly in JSON format:
{"label": "correct"|"wrong", "reason": "<short explanation>"}
```

Evidence is the sample's `cue_dialogue`, with line-start A/B names remapped using prediction speaker fields (`judge/evidence_loader.py:49–64`); there is no reference answer field for Cognitive. Accuracy is `correct / len(details)` (`run_judge.py:118–146`). Empty/failed predictions and unparseable judges become wrong (`:57–78,90–112`). Multiple judge runs produce a strict majority vote (`:244–250`), **not** an average of independently regenerated QA runs. The paper specifies three runs for LoCoMo only (`paper.txt:1359–1365`); do not silently apply that as the Plus main score.

The shared client sends one user message with model and temperature, without a transmitted max-token limit or seed (`T_mem/llm/llm_provider.py:111–129,330–339`). Configured/stored `max_tokens` is not an effective decoding cap in this call path. Record actual endpoint, resolved model identifiers, request parameters and responses. Temperature zero does not ensure identical provider outputs across time.

**Additional protocol discrepancy:** current upstream LoCoMo-Plus Cognitive judge is not verbatim identical. It allows predictions that “explicitly or implicitly” use the evidence and omits the Question block (`audit-public/official-evaluation_framework-task_eval-prompt.py:118–134`, pinned benchmark revision above). Its QA script defaults to temperature 0.3 (`official-...-evaluate_qa.py:104–105`), while T-Mem paper/release use 0. Do not substitute current benchmark prompts for T-Mem's released ones while calling the comparison matched. The paper says it follows official prompts (`paper.txt:4482–4489`) but does not reproduce the Plus templates; exact Table 4 prompt provenance remains unresolved.

## 4. Query access and leakage boundaries

**Confirmed transductive construction:** stage 0 explicitly appends the current test `trigger_query` as a conversation session (`stage0...:112–125`). Stage 1 loads *all* sessions and messages (`stage1_memory_extraction.py:48–95`), processes all raw messages, and flushes its final segment into a scene (`:131–198`). Its `_data_process` filters unsupported message types, not queries (`extractors/conv_scene_extractor.py:362–387`). Stage 4 generates triggers from the stored scene dialogue (`stage4_associative_extract.py:90–104,174–200`); stage 5 embeds every scene's raw dialogue (`stage5_retrieval_locomo.py:108–137`). There is no query-session exclusion in this route. Thus the held-out query can influence boundaries, summaries, derived triggers, and the searchable raw-dialogue channel.

This is **query access**, not proven answer-label leakage. Original benchmark full-context construction also appends the current query (`audit-public/official-data-build_conv.py:118–148`), which is appropriate when giving that context to a reader. Reusing the complete input for *memory construction* additionally makes the memory query-conditioned. A successful reproduction cannot establish performance of a pre-query frozen memory store. Removing the query before construction is a useful separate prospective sensitivity test, but would change the released method; do not conceal it inside the principal ablation.

The cue is the intended recall target and belongs in the memory history. It is not illicit “gold injection” merely because the judge also uses it. In this traced path, `scores`, `ranks`, `final_similarity_score`, and any original LoCoMo QA answers are not fed into construction: stage 0 copies base conversations and outputs empty QA, and stage 1 reads conversation fields only. No direct gold-label-to-generator path was found. Isolate judge evidence from retrieval/generation, and never select scenes/pilot cases using those generation scores or later judgments.

Construction quirks to freeze and disclose rather than quietly repair: stage 1 sorts session keys lexicographically (`stage1...:53–56`, so `session_10` precedes `session_2`), and time-gap parsing returns zero for unrecognized phrases (`benchmark_eval/locomo_plus/data/build_conv.py:22–49`). Scene IDs are UUIDs (`stage1...:181`; `extractors/conv_scene_extractor.py:330`), and stage-5 ties use scene ID. Rebuilding memory independently for each ablation therefore introduces unnecessary construction/tie differences.

## 5. Correct ablation intervention

Freeze **one** constructed memory, scene IDs, trigger texts, embeddings and query vectors for all arms. Let `b`, `scene`, and `horizon` denote the three stage-5 per-scene scores (`stage5_retrieval_locomo.py:172–188`). Use the same candidate universe, top-K, rank tie rule and RRF constant:

- Full: sum reciprocal ranks from **b + scene + horizon**.
- No Horizon: sum reciprocal ranks from **b + scene** only.
- No Scene + Horizon: sum reciprocal ranks from **b** only (equivalent ordering to raw-dialogue cosine with the same tie break).

Omit disabled **rank lists / RRF summands**, not just vectors or numerical similarities. The released `rrf_fuse_topk` always ranks all scenes in all three channels and adds all three reciprocal ranks (`:191–217`). Setting a channel to all zero still gives scene-ID-ordered positive votes. The same issue occurs for scenes with no usable generated triggers: code suppresses their vectors but still ranks their zero scores (`:114–118,182–187,204–214`). Keep that released behavior for enabled channels during a matched code reproduction, and disclose it; changing it is a separate method change.

For a paper-settings hierarchical run, feed each arm's revised scene association IDs into the **same** stage-6 scene-union hook; preserve topic expansion, raw-dialogue recall, Entity/Bridge item recall, reranking, persona and final context budgets. The union occurs before downstream scene BM25/vector/RRF/rerank (`stage6...:621–660`). Disabling the entire association hook would remove raw-dialogue `b` along with Scene/Horizon, so it is not the requested trigger-only intervention. No released CLI switch performs the precise three-arm channel mask; it needs a small explicit adapter or author code, not an environment-only “ablation.”

## 6. Minimal preregistered matched comparison

Do **not** start all 401 builds. First choose and label the track: (A) released-code diagnostic, keeping RRF 30 and top-10 summaries; or (B) paper-settings attempt after resolving/adapting the missing cascade, with RRF 60, final 5 scenes/15 items, topic 15, union 10, gate .85. A scene-only RRF-60 run is a third, adapted diagnostic, not track B.

Suggested diagnostic pilot: **20 samples**, five per relation type, selected before seeing outputs by ascending SHA-256 of UTF-8 `tmem-table4-pilot-v1:{original_index}` within each type. Exact original indices:

```text
9, 27, 47, 54, 58, 116, 128, 148, 160, 166,
214, 215, 244, 265, 294, 301, 302, 349, 367, 398
```

The executable-independent manifest is `audit-public/pilot-manifest.json`. It preserves `sample_NNN`, original index and `base_conv_idx = original_index % 10`. This is a balanced diagnostic sample, not an unbiased estimate of the 401-row weighted score; it also does not cover every base-conversation stratum. Never compact/reindex it and then use `i % 10`, because that changes histories and judge evidence. The first 20/25 rows are all causal, so the README-style prefix smoke is not a representative ablation pilot.

1. Freeze code/data/prompt/model/request manifests and predeclare the chosen track. Build these sample libraries once with the prescribed construction model. Validate query/cue provenance, scene IDs, generated trigger coverage and embedding identity before spending on QA.
2. Retrieve all three arms using the exact masks above. Assert b-only ordering, disabled-channel nonparticipation, matched IDs and context format, and no omitted/missing libraries. Persist full per-channel scores/ranks and final selected IDs. Retrieval cue-recall is a secondary diagnostic only; it is not the Table 4 endpoint.
3. Run the same GPT-4o reader and Gemini-2.5-Flash judge on all 20 units per arm with the frozen released prompts (or an explicitly author-confirmed alternative). This is 60 predictions/60 one-run judgments after construction. Keep each arm in a distinct output directory; do not reuse QA/judge caches across arms. Randomize/interleave arm execution and blind arm names in judgments.
4. Publish all per-unit labels and paired win/loss/tie counts, absolute accuracy, full-minus-noHT and full-minus-noSTHT deltas, and a paired uncertainty summary. Separate infrastructure/parse failures from actual incorrect judgments; do not silently drop them. A 20-unit result tests machinery and effect direction, **not** replication of 74.81% or the exact +22.19 pp effect.
5. Only expand a locked, functioning protocol to all **401** original IDs. Preserve failed units in the denominator and separately show failure rates. Report sensitivity to query-free construction or current official judge as distinct follow-ups, never by replacing a disappointing main result.

## 7. Runner pitfalls that can invalidate the pilot

- Stage 5 takes `min(number_of_samples, number_of_scene_files)` and processes a prefix (`stage5...plus:114–132`); sparse original-index libraries are not supported as-is. A selected-ID adapter is required for the pilot above.
- Stage 8 iterates the entire input dataset and emits `(Error: no topk rows)` for absent rows (`stage8...plus:306–327`), so `build_memory --limit 20` alone does **not** create a 20-row scoring experiment.
- Judge `build_evidence_and_reltype_maps(predictions)` reloads its hard-coded default dataset; it does not consume the shell's `--locomo-plus-file`/environment override (`judge/evidence_loader.py:17–23,37–43`; `run_judge.py:333–334`). Retain original IDs and supply the pinned full evidence list explicitly in an adapter, or prove the default file hash matches. A compact dataset override alone can silently judge against the wrong cues.
- QA resume trusts successful `sample_id` records without checking retrieval/model/prompt changes (`stage8...plus:280–301`). Judge cache validation compares only model, prompt key, run count and prediction count, not prediction contents (`run_judge.py:184–197`). Different arm directories or content-addressed manifests are necessary; changing retrieval in the same experiment can return a stale “result.”
- Missing Entity/Bridge artifacts fall back to baseline in the hierarchical path (`stage6...:38–42`); merely setting its enabled flag is not proof it participated. The same standard applies to persona/reranker/context contents. Inspect actual final reader inputs.

## 8. Published artifacts and permissible claims

No downloadable full frozen memory/prediction/judgment package was found in the inspected T-Mem Git tree, README/project documentation, or GitHub releases API (zero releases at audit time). The tracked `docs/demo/demo_data.json` contains six scene examples and six QA examples, and `docs/README.md:34–36` explicitly calls these illustrative, not new benchmark results. They are not a frozen 401-sample evaluation. Paper-source Overleaf files are separately maintained (`docs/README.md:17–21`), not included. Saved release/tree inventories document the scope of this negative finding; it does not prove artifacts do not exist elsewhere.

The main comparison borrows some baseline scores: Table 3 names Mem0, SeCom, A-Mem, GPT-4o and Gemini-2.5-Pro as taken from prior work (`paper.txt:1147–1158`). Use the **author's within-system Table 4 ablation** as the target, not a claim that borrowed baseline numbers came from matched new runs.

**Allowed conclusion after a successful pilot:** “On these 20 pinned Cognitive samples, the released/adapted T-Mem route improved memory-awareness judgments by X paired points when Scene/Horizon ranks were enabled.” **Not allowed:** “We replicated Table 4,” “we reproduced the same cascade,” “this proves pre-query memory retrieval improves,” or any statement that this audit measured a gain. The closest route to a faithful Table 4 claim is an author-confirmed Plus hierarchical runner, exact prompts/query-boundary policy and frozen artifacts; absent that, a documented reconstruction must remain labeled as such.
